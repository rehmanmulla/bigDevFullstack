import { useContext, useEffect, useState } from "react";
import { Context } from "../../context/Context";
import FileUploadOutlinedIcon from '@mui/icons-material/FileUploadOutlined';
import "./profile.scss";
import axios from "axios";
import Navbar from "../../components/navbar/Navbar";

const Profile = () => {
  const { user, dispatch } = useContext(Context);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get("/user/" + user.username);
        dispatch({ type: "UPDATE_SUCCESS", payload: res.data });
      } catch (error) {
        console.error(error.message);
      }
    }
    fetchData();
  }, [dispatch, user.username]);

  const [file, setFile] = useState(null);
  const [name, setName] = useState(user.name);
  const [username, setUsername] = useState(user.username);
  const [email, setEmail] = useState(user.email);
  const [password, setPassword] = useState(user.password);
  const [city, setCity] = useState(user.city);
  const [website, setWebsite] = useState(user.website);
  const [success, setSuccess] = useState(false);

  const PF = "http://localhost:5000/images/"

  const handleSubmit = async (e) => {
    e.preventDefault();
    dispatch({ type: "UPDATE_START" });
    const updatedUser = {
      userId: user._id,
      name,
      username,
      email,
      password,
      city,
      website
    };
    if (file) {
      const data = new FormData();
      const filename = Date.now() + file.name;
      data.append("name", filename);
      data.append("file", file);
      updatedUser.profilePic = filename;
      try {
        await axios.post("/upload", data);
      } catch (err) {}
    }
    try {
      const res = await axios.put("/user/" + user._id, updatedUser);
      setSuccess(true);
      dispatch({ type: "UPDATE_SUCCESS", payload: res.data });
    } catch (err) {
      dispatch({ type: "UPDATE_FAILURE" });
    }
  };
  return (
    <>
      <Navbar/>
      <div className="profile">
        <div className="profileWrapper">
          <div className="profileTitle">
            <span className="profileUpdateTitle">Update Your Profile</span>
          </div>
          <form className="profileForm" onSubmit={handleSubmit}>
            <label>Profile Picture</label>
            <div className="profilePP">
              <img src= {file ? URL.createObjectURL(file) : PF+user.profilePic} alt=""/>
              <label htmlFor="fileInput" className="profilePPIcon">
                <FileUploadOutlinedIcon />
              </label>
              <input type="file" id="fileInput" style={{ display: "none" }} onChange={(e) => setFile(e.target.files[0])}/>
            </div>
            <label>Name</label>
            <input type="text" placeholder={user.name} onChange={(e) => setName(e.target.value)}/>
            <label>Username</label>
            <input type="text" placeholder={user.username} onChange={(e) => setUsername(e.target.value)}/>
            <label>Email</label>
            <input type="email" placeholder={user.email} onChange={(e) => setEmail(e.target.value)}/>
            <label>Password</label>
            <input type="password" placeholder={user.password} onChange={(e) => setPassword(e.target.value)}/>
            <label>City</label>
            <input type="text" placeholder={user.city} onChange={(e) => setCity(e.target.value)}/>
            <label>Website</label>
            <input type="text" placeholder={user.website} onChange={(e) => setWebsite(e.target.value)}/>
            <button className="profileSubmit" type="submit">Update</button>
            {success && (
              <span style={{ color: "green", textAlign: "center", marginTop: "20px" }}>
                Profile has been updated...
              </span>
            )}
          </form>
        </div>
      </div>
    </>
  );
}

export default Profile;