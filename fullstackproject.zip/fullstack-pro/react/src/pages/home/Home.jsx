import "./home.scss";
import AccountBoxOutlinedIcon from '@mui/icons-material/AccountBoxOutlined';
import FacebookTwoToneIcon from "@mui/icons-material/FacebookTwoTone";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import InstagramIcon from "@mui/icons-material/Instagram";
import TwitterIcon from "@mui/icons-material/Twitter";
import PlaceIcon from "@mui/icons-material/Place";
import LanguageIcon from "@mui/icons-material/Language";
import ModeEditOutlineOutlinedIcon from '@mui/icons-material/ModeEditOutlineOutlined';
import { useContext } from "react";
import { Context } from "../../context/Context";
import Navbar from "../../components/navbar/Navbar";
import { Link } from "react-router-dom";

const Home = () => {
  const { user } = useContext(Context);
  const PF = "http://localhost:5000/images/";

  return (
    <>
    <Navbar/>
    <div className="home">
      <div className="images">
        <img className="coverPic" alt=""
          src='https://i.pinimg.com/originals/4a/88/7e/4a887e68509737452a38ba244079b8a0.jpg'
        />
      </div>
      <div className="homeContainer">
        <div className="uInfo">
          <div className="left">
            <div className="image">
              <img
                src={user.profilePic ? PF+user.profilePic : 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'}
                alt=""
                className="profilePic"
              />
            </div>
          </div>
          <div className="right">
            <div className="editIcon">
              <span>{user.name}</span>
              <Link to="/profile" style={{ textDecoration: "none", color: "black" }}>
                <ModeEditOutlineOutlinedIcon />
              </Link>              
            </div>
            <div className="info">
              <div className="item">
                <AccountBoxOutlinedIcon />
                <span>{user.username}</span>
              </div>
              <div className="item">
                <PlaceIcon />
                <span>{user.city}</span>
              </div>
              <div className="item">
                <LanguageIcon />
                <span>{user.website}</span>
              </div>
            </div>
            <div className="followICon">
              <a href="_blank">
                <FacebookTwoToneIcon fontSize="large" />
              </a>
              <a href="_blank">
                <InstagramIcon fontSize="large" />
              </a>
              <a href="_blank">
                <TwitterIcon fontSize="large" />
              </a>
              <a href="_blank">
                <LinkedInIcon fontSize="large" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default Home;
