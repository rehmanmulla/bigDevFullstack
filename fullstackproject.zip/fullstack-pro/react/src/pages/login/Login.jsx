import axios from "axios";
import { useContext, useState } from "react";
import { Link } from "react-router-dom";
import { Context } from "../../context/Context";
import "./login.scss";

const Login = () => {
  const [inputs, setInputs] = useState({
    username: '',
    password: '',
  });
  const [error, setError] = useState(false);

  const handleChange = (e) => {
    setInputs(prev => ({...prev, [e.target.name]: e.target.value}));
  }
  const { dispatch } = useContext(Context);

  const handleLogin = async (e) => {
    e.preventDefault()
    dispatch({type: "LOGIN_START"});
    try {
      const res = await axios.post("/auth/login", inputs)
      dispatch({type: "LOGIN_SUCCESS", payload: res.data});
      setError(false);
      res.data && window.location.replace("/");
    } catch (error) {
      setError(error.response.data);
      dispatch({type: "LOGIN_FAILURE"});
    }
  };

  return (
    <div className="login">
      <div className="card">
        <div className="left">
          <h1>SignUp Free</h1>
          <p>
            Just one click away!! No account no worry Sign up here free, Will see you after login hurry!! 
          </p>
          <span>Don't you have an account?</span>
          <Link to="/register">
            <button>Register</button>
          </Link>
        </div>
        <div className="right">
          <h1>Login</h1>
          <form>
            <input type="text" placeholder="Username" name="username" onChange={handleChange}/>
            <input type="password" placeholder="Password" name="password" onChange={handleChange}/>
            <button onClick={handleLogin}>Login</button>
            {error && <span style={{color:"red"}}>{error}</span>}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
