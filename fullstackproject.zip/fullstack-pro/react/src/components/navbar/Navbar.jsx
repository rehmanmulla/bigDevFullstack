import "./navbar.scss";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import LoginOutlined from "@mui/icons-material/LoginOutlined";
import { Link } from "react-router-dom";
import { useContext } from "react";
import { Context } from "../../context/Context";

export default function Navbar() {  
  const { user, dispatch } = useContext(Context);
  const PF = "http://localhost:5000/images/";

  const handleLogout = () => {
    dispatch({type: "LOGOUT"});
    window.location.replace("/login");
  };

  return (
    <div className="navbar">
      <div className="left">
        <Link to="/" style={{ textDecoration: "none", color: "black" }}>
          <HomeOutlinedIcon />
        </Link>
      </div>
      <div className="right">
          <div className="user">
            <Link to="/profile">
                <img src={user.profilePic ? PF+user.profilePic : 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png'} alt="" />
                <span>{user.name}</span>
            </Link>
          </div>          
        <div className="logout" onClick={handleLogout}><LoginOutlined /></div>
      </div>
    </div>
  );
};
