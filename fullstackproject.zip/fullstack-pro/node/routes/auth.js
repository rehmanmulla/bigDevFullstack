const router = require("express").Router();
const User = require('../models/User');

router.post("/login", async (req, res) => {
    try {
        const user = await User.findOne({ username: req.body.username });
        if (!user) {
            return res.status(400).json("No User Found");
        }
        if (user.password === req.body.password) {
            const { password, ...others } = user._doc;
            return res.status(200).json(others);
        }
        return res.status(400).json('Wrong credentials!');
    } catch (err) {
        return res.status(500).json(err);
    }
});

module.exports = router